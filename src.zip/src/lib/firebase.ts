import { initializeApp } from "firebase/app";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
    apiKey: "AIzaSyDb_-Pl7fMEQiBnYmi1TqZeASQMSLbwAnk",
    authDomain: "alaa-760fd.firebaseapp.com",
    databaseURL: "https://alaa-760fd.firebaseio.com",
    projectId: "alaa-760fd",
    storageBucket: "alaa-760fd.firebasestorage.app",
    messagingSenderId: "110443455564",
    appId: "1:110443455564:web:78a530522599d8aa5680e9",
    measurementId: "G-PNT0S6D9MT"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);